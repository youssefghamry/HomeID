<?php
/**
 * Element class
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_G5Element_Slider_Container extends G5Element_ShortCode_Container {
}

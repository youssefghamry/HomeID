Changelog
=========
#### 1.1.4 - October 19, 2021
* Update option select post layout for section related posts

#### 1.1.3 - July 20, 2021
* Fix PHP Deprecated: Function _register_controls

### 1.1.2 - October 16, 2021
* Fix duplicate breadcrumb in single product when using elementor

### 1.1.1 - July 15, 2021
* Fix Elementor widget posts slider

### 1.1.0 - May 17, 2021
* Add Elementor widget posts slider

### 1.0.9 - February 18, 2021
* Add Elementor widget posts

### 1.0.8 - January 12, 2020
* Fix style post sticky large-image

### 1.0.7 - December 29, 2020
* Fix style line ending both DOS and UNIX

### 1.0.6 - September 21, 2020
* Fix set post per page for archive blog

### 1.0.5 - July 08, 2020
* Add config item custom class
<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
/**
 * @var $property_garage
 */
?>
<span class="g5ere__loop-property-garage"><?php echo sprintf(esc_html__('%s Gr','g5-ere'),$property_garage)?></span>

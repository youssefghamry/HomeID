<?php

namespace ElementorPro\Base\MarkerInterfaces;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

interface Archive_Template_Interface {
}
